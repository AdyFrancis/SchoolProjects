
public class SDSTest {

	
	private String tech;
	private String dvd;
	private String test;
	private int failed;
	private String line;
	
	public SDSTest(String tech, String dvd, String test, int failed, String line) {
		this.tech = tech;
		this.dvd = dvd;
		this.test = test;
		this.failed = failed;
		this.line = line;
	}
	
	public SDSTest(String tech, String dvd, String test) {
		this.tech = tech;
		this.dvd = dvd;
		this.test = test;
		this.failed = 0;
		this.line = "";
	}
	
	
	public String getTech() {
		return this.tech;
	}
	
	public String getDVD() {
		return this.dvd;
	}
	
	public String getTest() {
		return this.test;
	}
	
	public int getFailed() {
		return this.failed;
	}
	
	public String getLine() {
		return this.line;
	}
	
}
