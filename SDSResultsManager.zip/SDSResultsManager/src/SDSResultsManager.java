import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SDSResultsManager {

	
	private static ArrayList<String> skipped;
	private static ArrayList<SDSTest> hay;
	private static ArrayList<String> subjects;
	private static ArrayList<SDSTest> failed;
	private static PrintWriter out;

	
	public static void main(String[] args) throws IOException {
		
		BufferedReader in = null;
        in = new BufferedReader(new InputStreamReader(System.in));
        
        File output = new File("SDSRM.OUT");
        if (output.exists())
        	output.delete();
        
        out = new PrintWriter("SDSRM.OUT");

        System.out.print("Enter script to cross-reference: ");
		
		String script = in.readLine();
		//                          devtest/runs/94M5/
		File scriptFile = new File("U:\\crontemp\\torun\\done\\" + script);
		if (!scriptFile.exists()) {
			exitError(scriptFile.getAbsolutePath() + " not found.");
		}
		
		File inboxData = new File ("U:\\inbox.csv");
		//grabMail(inboxData);	
		
		
		BufferedReader br = null;
		BufferedReader sr = null;
		
		
		try {
			
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(inboxData), "UTF-16"));
	        sr = new BufferedReader(new InputStreamReader(new FileInputStream(scriptFile)));
		}
		catch (IOException ioe) {
			exitError("ERROR with BufferedReader: " + ioe.getMessage());
		}
		
		
		subjects = new ArrayList<String>();	
		skipped = new ArrayList<String>();
		failed = new ArrayList<SDSTest>();
		
		hay = readScriptFile(scriptFile, sr);
		
		int total = hay.size();
		parseCSVFile(inboxData, br);
		total = total - hay.size();
		
		System.out.println();
		
		
        PrintWriter subjWriter = new PrintWriter("U:\\subjects.txt");
		for (String s: subjects) {
			subjWriter.println(s);
		}
		
		subjWriter.close();
		
		System.out.println(total + " emails were found.");
		
		deleteMail();
		out.println();
		out.println(subjects.size() + " emails deleted.");
		out.println();
		
		System.out.println(failed.size() + " emails with more than 0 failures.");
		out.println();
		out.println(failed.size() + " emails with more than 0 failures:");
		
		for (SDSTest sds : failed){
			out.println(sds.getLine());
		}
		
		File subj = new File("U:\\subjects.txt");
		//if (subj.exists())
			//subj.delete();
		out.close();
		
		System.out.println("See SDSRM.OUT for more information.");
		
	}

	
	public static void exitError(String message) {
		System.out.println(message);
		System.out.println("Exiting...");
		System.exit(1);
	}
	
	public static void parseCSVFile(File inboxData, BufferedReader br) {
		
		System.out.println("Parsing inbox.csv...");

		String line = "";
		try {
			while ((line = br.readLine()) != null) {
				String[] lineArr = line.split("\\s+");
				String[] subLineArr = lineArr[6].split(":");
				SDSTest sds = null;
				
				if (lineArr[0].equals("C0R11") && lineArr.length == 10)
					sds = new SDSTest(lineArr[4], subLineArr[0], subLineArr[2], Integer.parseInt(lineArr[8]), line);
				else if (lineArr.length == 9)
					sds = new SDSTest(lineArr[4], subLineArr[0], subLineArr[2], Integer.parseInt(lineArr[7]), line);
				else if (lineArr.length == 8)
					sds = new SDSTest(lineArr[4], subLineArr[0], subLineArr[2], 0, line);
				else {
					skipped.add(line);
					sds = null;
				}
				
				if (sds != null) {
					if(find(sds)) {
						if (sds.getFailed() >= 0)
							subjects.add(sds.getLine());
					}
				}

			}
		}
		catch (IOException ioe) {
			exitError("ERROR reading CSV file\n" + ioe.getMessage());
		}
		
		if (hay.size() > 2)
			out.println(hay.size() + " tests not found in the inbox:");
		else if (hay.size() == 1)
			out.println("1 test not found in the inbox.");
		else
			out.println("All tests were found in the inbox.");
		
		out.println();
		
		for (SDSTest sds : hay)
			out.println(sds.getLine());
		
		out.println();
	}

	public static ArrayList<SDSTest> readScriptFile(File script, BufferedReader br) {
		
		System.out.println("Reading " + script.getName());
		ArrayList<SDSTest> scriptArray = new ArrayList<SDSTest>();
		
		String line = "";
		
		
		try {
			while ((line = br.readLine())!= null) {
				SDSTest sds = null;
				if (line.length() < 25 || line.trim().charAt(0) == '#') {
					continue;
				}
				String[] lineArr = line.trim().split("\\s+");
				if (lineArr.length == 8) {
					sds = new SDSTest(lineArr[3], lineArr[5], lineArr[6], 0, line);
				}
				else {
					System.out.println(line);
					sds = new SDSTest(lineArr[5], lineArr[7], lineArr[8], 0, line);
				}
				
				scriptArray.add(sds);
			}
		}
		catch (IOException ioe) {
			exitError("ERROR reading " + script.getName() + "\n" + ioe.getMessage());
		}
		
		System.out.println();
		System.out.println(scriptArray.size() + " tests loaded from the script file.");
		return scriptArray;
	}
	
	
	public static boolean find (SDSTest needle) {
		
		for (SDSTest sds: hay) {
			if (sds.getTech().equals(needle.getTech()) && 
			    sds.getDVD().equals(needle.getDVD()) && 
			    sds.getTest().equals(needle.getTest())) {
				
				if (needle.getFailed() > 0)
					failed.add(sds);
				
				hay.remove(sds);
				return true;
			}
		}
		
		return false;
	}
	
	
	public static void deleteMail() {
		Runtime runtime = Runtime.getRuntime();
		Process proc = null;
		
		try {
			System.out.println("Deleting " + subjects.size() +  " emails with 0 failures. This may take a bit.");
			proc = runtime.exec("powershell -NoProfile -Command U:\\maildelete.ps1");
			proc.waitFor();
		}
		catch (Exception e) {
			exitError(e.getCause().toString() + "\n" + e.getMessage());
		}
	}
	
	public static void grabMail(File inboxData) {
		
		if (inboxData.exists()) {
			System.out.println("Old inbox.csv file detected. Deleting.");
			boolean deleted = inboxData.delete();
			if (!deleted) {
				exitError("Error deleting file U:/inbox.csv");
			}
		}
		
		Runtime runtime = Runtime.getRuntime();
		Process proc = null;
		
		try {
			System.out.println("Generating new inbox.csv file. This may take a bit.");
			proc = runtime.exec("powershell -NoProfile -Command U:\\mailgrab.ps1");
			proc.waitFor();
		}
		catch (Exception e) {
			exitError(e.getCause().toString() + "\n" + e.getMessage());
		}
		
		
		
		if (!inboxData.exists())
			exitError("File " + inboxData.getAbsolutePath() + " not found.");
	}
}
